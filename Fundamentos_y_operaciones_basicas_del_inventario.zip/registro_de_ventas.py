# Solicitar el nombre del producto
nombre = input("Ingrese el nombre del producto: ")

# Solicitar y validar el precio
while True:
    try:
        precio = float(input("Ingrese el precio del producto: "))
        break
    except ValueError:
        print("Valor inválido. Debe ingresar un número para el precio.")

# Solicitar y validar la cantidad
while True:
    try:
        cantidad = int(input("Ingrese la cantidad del producto: "))
        break
    except ValueError:
        print("Valor inválido. Debe ingresar un número entero para la cantidad.")

# Calcular el costo total
costo_total = precio * cantidad

# Mostrar resultados en consola
print("\n--- Información del producto ---")
print("Nombre del producto:", nombre)
print("Precio unitario:", precio)
print("Cantidad:", cantidad)
print("Costo total:", costo_total)



# Este programa solicita al usuario el nombre de un producto, su precio y la cantidad.
# Valida que el precio sea un número decimal y que la cantidad sea un número entero.
# Si el usuario ingresa un valor inválido, el programa vuelve a pedir el dato.
# Después de obtener valores correctos, calcula el costo total multiplicando el precio
# por la cantidad y finalmente muestra toda la información del producto en la consola.