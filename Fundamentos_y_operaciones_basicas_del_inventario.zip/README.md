# Fundamentos_y_operaciones_basicas_del_inventario

# Calculadora de Costo de Producto 

## Descripción

Este proyecto es un programa sencillo en Python que calcula el costo total de un producto. Es un script de nivel inicial diseñado para demostrar cómo funcionan la entrada de usuario, los bucles y el manejo de errores en Python.

El programa solicita al usuario que ingrese el nombre de un producto, el precio y la cantidad.


## Tecnologías y Conceptos Utilizados

* *Lenguaje:* Python 3.x
* *Lógica Condicional y Control de Flujo:* * Uso de bloques try-except para la validación de tipos de datos.
    * Bucles while True para repetir la solicitud de datos hasta que sean válidos.
* *Operaciones Matemáticas:* Cálculo de producto simple.

## Funciones de Python Implementadas

Para el funcionamiento de este script, se utilizaron las siguientes funciones integradas:

1.  input(): Para capturar la información escrita por el usuario.
2.  float(): Para convertir la entrada del precio en un número decimal.
3.  int(): Para asegurar que la cantidad sea un número entero.
4.  print(): Para mostrar los resultados y mensajes de error en la consola.

## Cómo funciona

1.  El programa solicita el nombre del producto y lo almacena en una variable.
2.  Solicita el precio y verifica si el valor es un número decimal válido.
3.  Si el valor es inválido (por ejemplo, si se ingresan letras), el programa muestra un mensaje de error y solicita el precio nuevamente.
4.  Solicita la cantidad y valida que el valor sea un número entero.
5.  Calcula el costo total multiplicando el precio por la cantidad.
6.  Imprime la información detallada del producto y el costo final en la consola.

## Estado del Proyecto

> El programa se encuentra actualmente como un proyecto de aprendizaje básico, demostrando el manejo de entradas y la validación de datos en Python.
